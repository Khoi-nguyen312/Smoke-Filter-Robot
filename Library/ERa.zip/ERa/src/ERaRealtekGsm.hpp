#ifndef INC_ERA_REALTEK_GSM_HPP_
#define INC_ERA_REALTEK_GSM_HPP_

#define ERA_MODBUS

#include <ERaSimpleRealtekGsm.hpp>

#endif /* INC_ERA_REALTEK_GSM_HPP_ */
