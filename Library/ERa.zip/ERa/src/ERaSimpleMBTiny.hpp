#ifndef INC_ERA_SIMPLE_MODBUS_TINY_HPP_
#define INC_ERA_SIMPLE_MODBUS_TINY_HPP_

#define ERA_MODBUS

#include <ERaSimpleTiny.hpp>

#endif /* INC_ERA_SIMPLE_MODBUS_TINY_HPP_ */
