#ifndef INC_ERA_PARTICLE_HPP_
#define INC_ERA_PARTICLE_HPP_

#define ERA_MODBUS

#include <ERaSimpleParticle.hpp>

#endif /* INC_ERA_PARTICLE_HPP_ */
