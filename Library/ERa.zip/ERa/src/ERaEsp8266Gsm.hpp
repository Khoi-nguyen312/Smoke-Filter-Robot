#ifndef INC_ERA_ESP8266_GSM_HPP_
#define INC_ERA_ESP8266_GSM_HPP_

#define ERA_MODBUS

#include <ERaSimpleEsp8266Gsm.hpp>

#endif /* INC_ERA_ESP8266_GSM_HPP_ */
