#ifndef INC_ERA_LOGICROM_HPP_
#define INC_ERA_LOGICROM_HPP_

#define ERA_MODBUS

#include <ERaSimpleLogicrom.hpp>

#endif /* INC_ERA_LOGICROM_HPP_ */
