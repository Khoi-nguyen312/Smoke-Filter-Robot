#ifndef INC_ERA_ARDUINO_WIFI_AT_HPP_
#define INC_ERA_ARDUINO_WIFI_AT_HPP_

#define ERA_MODBUS

#include <ERaSimpleArduinoWiFiAT.hpp>

#endif /* INC_ERA_ARDUINO_WIFI_AT_HPP_ */
