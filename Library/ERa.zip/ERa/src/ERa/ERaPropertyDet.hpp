#ifndef INC_ERA_PROPERTY_DETECT_HPP_
#define INC_ERA_PROPERTY_DETECT_HPP_

#if !defined(ERA_ABBR)
    #include <ERa/ERaProperty.hpp>
#else
    #include "types/WrapperTypes.hpp"
#endif

#endif /* INC_ERA_PROPERTY_DETECT_HPP_ */
