#ifndef INC_ERA_REALTEK_SSL_WIFI_HPP_
#define INC_ERA_REALTEK_SSL_WIFI_HPP_

#define ERA_MODBUS

#include <ERaSimpleRealtekSSLWiFi.hpp>

#endif /* INC_ERA_REALTEK_SSL_WIFI_HPP_ */
