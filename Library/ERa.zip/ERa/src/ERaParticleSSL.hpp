#ifndef INC_ERA_PARTICLE_SSL_HPP_
#define INC_ERA_PARTICLE_SSL_HPP_

#define ERA_MODBUS

#include <ERaSimpleParticleSSL.hpp>

#endif /* INC_ERA_PARTICLE_SSL_HPP_ */
